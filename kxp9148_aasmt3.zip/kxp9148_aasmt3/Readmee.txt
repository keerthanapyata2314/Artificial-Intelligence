NAME: KEERTHANA PYATA
UTA ID: 1002029148
Net ID: kxp9148
PROGRAMMING LANGUAGE USED AND VERSION
I have used python programming language and version is 3.10.9.
How the code is structured:
Imports: The Pandas library is imported in the first line of code.
Function Definition: A function called calculate_probabilities() is defined that takes a Pandas data frame as input and calculates the probabilities of different events in the dataset. It calculates the probability of B, the probability of G given B, the probability of F given G and C, and the probability of C. It returns these probabilities.
Function Definition: A function called read_training_data() is defined that takes a file name as input and reads in the data from the file in the form of a Pandas dataframe. The function then returns the data frame.
Main Function: The main() function is defined, which is where the main logic of the program resides. It first defines the file path of the training data and reads it in using the read_training_data() function.
Probability Calculation: The probabilities of different events are calculated using the calculate_probabilities() function and stored in variables.
Output: The calculated probabilities are then printed to the console using the print() function.
Execution: Finally, the main() function is executed if the script is being run as the main program, i.e., if __name__ == '__main__'


