import sys
import datetime
from queue import LifoQueue, PriorityQueue
from queue import Queue
from queuelib import LifoDiskQueue
import argparse


start_file = sys.argv[1]
goal_file = sys.argv[2]
method = sys.argv[3]
dump_flag = sys.argv[4]

FOUND = 0






class Node:
    def __init__(self, state, heuristic, parent=None, move=None, cost=0):
        self.state = state
        self.parent = parent
        self.move = move
        self.cost = cost
        self.heuristic = heuristic(state, goal_state) if heuristic else 0
        self.total_cost = self.cost + self.heuristic
        if parent:
            self.depth = parent.depth + 1
        else:
            self.depth = 0
    def expand(self):
        successors = []
        for move, action in self.state.get_actions().items():
            new_state = self.state.move(action)
            new_node = Node(new_state, self, self.depth+1, self.heuristic)
            successors.append(new_node)
        return successors        
    
def parse_input_file(filename):
    with open(filename, 'r') as f:
        lines = f.readlines()
        state = [int(x) for x in lines[0].split()]
        goal = [int(x) for x in lines[1].split()]
    return state, goal

def manhattan_distance(state, goal_state):
    distance = 0
    for i in range(len(state)):
        if state[i] != '0':
            # Get the row and column of the current state value
            row = i // 3
            col = i % 3

            # Find the goal state value and its row and column
            goal_index = tuple(goal_state.index(state[i]))
            goal_row = goal_index // 3
            goal_col = goal_index % 3

            # Add the Manhattan distance between the current and goal positions
            distance += abs(row - goal_row) + abs(col - goal_col)
    return distance


start_state, goal_state = parse_input_file(start_file), parse_input_file(goal_file)
start_node = Node(start_state, heuristic=manhattan_distance(start_state, goal_state))
goal_node = Node(goal_state, heuristic=manhattan_distance(start_state, goal_state))


def generate_successors(node):
    successors = []
    state = node.state
    row, col = node.blank_tile
    moves = [(0, -1), (0, 1), (-1, 0), (1, 0)]  # left, right, up, down
    for move in moves:
        new_row = row + move[0]
        new_col = col + move[1]
        if 0 <= new_row <= 2 and 0 <= new_col <= 2:
            new_state = [row[:] for row in state]
            new_state[row][col], new_state[new_row][new_col] = new_state[new_row][new_col], new_state[row][col]
            successors.append(Node(new_state, (new_row, new_col), node.cost + state[new_row][new_col]))
    return successors

def is_goal(node, goal_state):
    return node.state == goal_state

def cost(path):
    return sum(node.cost for node in path[1:])




def bfs(start, goal):
    
    fringe = Queue()
    closed_set = set()
    nodes_expanded = 0
    nodes_generated = 0

    fringe.put(Node(start, None, 0, 0))

    while not fringe.empty():
        node = fringe.get()
        nodes_expanded += 1

        if node.state == goal:
            path = get_path(node)
            return path, fringe.qsize(), len(closed_set), nodes_expanded, nodes_generated

        closed_set.add(node.state)

        for successor in node.expand():
            nodes_generated += 1
            if successor.state not in closed_set:
                fringe.put(successor)

    return None

def ucs(start, goal):
    
    fringe = PriorityQueue()
    closed_set = set()
    nodes_expanded = 0
    nodes_generated = 0

    fringe.put(Node(start, None, 0, 0))

    while not fringe.empty():
        node = fringe.get()
        nodes_expanded += 1

        if node.state == goal:
            path = get_path(node)
            return path, fringe.qsize(), len(closed_set), nodes_expanded, nodes_generated

        closed_set.add(node.state)

        for successor in node.expand():
            nodes_generated += 1
            if successor.state not in closed_set:
                fringe.put(successor)

    return None

def get_path(node):
    path = []
    while node:
        path.append(node.state)
        node = node.parent
    return path[::-1]

def dls(start, goal, depth, heuristic):
      
    fringe = LifoQueue()
    closed_set = set()
    nodes_expanded = 0
    nodes_generated = 0

    fringe.put(Node(start, None, 0, heuristic(start, goal)))

    while not fringe.empty():
        node = fringe.get()
        nodes_expanded += 1

        if node.state == goal:
            path = get_path(node)
            return path, fringe.qsize(), len(closed_set), nodes_expanded, nodes_generated

        closed_set.add(node.state)

        if node.depth < depth:
            for successor in node.expand():
                nodes_generated += 1
                if successor.state not in closed_set:
                    fringe.put(successor)

    return None







def greedy(start, goal, heuristic):
   
    fringe = PriorityQueue()
    closed_set = set()
    nodes_expanded = 0
    nodes_generated = 0

    fringe.put(Node(start, None, 0, heuristic(start, goal)))

    while not fringe.empty():
        node = fringe.get()
        nodes_expanded += 1

        if node.state == goal:
            path = get_path(node)
            return path, fringe.qsize(), len(closed_set), nodes_expanded, nodes_generated

        closed_set.add(node.state)

        for successor in node.expand():
            nodes_generated += 1
            if successor.state not in closed_set:
                fringe.put(Node(successor.state, node,g_cost=node.g_cost + successor.cost, h_cost=heuristic(successor.state, goal)))
                return None, fringe.qsize(), len(closed_set), nodes_expanded, nodes_generated

def astar(start, goal, heuristic):
   
    fringe = PriorityQueue()
    closed_set = set()
    nodes_expanded = 0
    nodes_generated = 0
    solution = astar(start_state, goal_state, heuristic=manhattan_distance)


    fringe.put(Node(start, None, 0, heuristic(start, goal)))

    while not fringe.empty():
        node = fringe.get()
        nodes_expanded += 1

        if node.state == goal:
            path = get_path(node)
            return path, fringe.qsize(), len(closed_set), nodes_expanded, nodes_generated

        closed_set.add(node.state)

        for successor in node.expand():
            nodes_generated += 1
            if successor.state not in closed_set:
                g = node.g + 1
                h = heuristic(successor.state, goal)
                fringe.put(Node(successor.state, node, g, h))

    return None

def ids(start, goal, heuristic):
    
    bound = heuristic(start, goal)
    nodes_expanded = 0
    nodes_generated = 0

    while True:
        result = search([start], 0, bound, goal, heuristic, nodes_expanded, nodes_generated)
        if result == FOUND:
            path = get_path(Node(goal, None, 0, 0))
            return path, None, None, nodes_expanded, nodes_generated
        if result == float('inf'):
            return None, None, None, nodes_expanded, nodes_generated
        bound = result


def search(path, g, bound, goal, heuristic, nodes_expanded, nodes_generated):
   
    node = Node(path[-1], None, g, heuristic(path[-1], goal))
    f = node.depth + node.heuristic
   

    if f > bound:
        return f

    if node.state == goal:
        return FOUND

    min_bound = float('inf')

    for successor in node.expand():
        nodes_generated += 1
        if successor.state not in path:
            path.append(successor.state)
            t = search(path, g + 1, bound, goal, heuristic, nodes_expanded, nodes_generated)
            if t == FOUND:
                return FOUND
            if t < min_bound:
                min_bound = t
            path.pop()

        nodes_expanded += 1

    return min_bound


def dfs(start, goal, heuristic):
    
    fringe = LifoQueue()
    closed_set = set()
    nodes_expanded = 0
    nodes_generated = 0

    fringe.put(Node(start, None, 0, heuristic(start, goal)))

    while not fringe.empty():
        node = fringe.get()
        nodes_expanded += 1

        if node.state == goal:
            path = get_path(node)
            return path, fringe.qsize(), len(closed_set), nodes_expanded, nodes_generated

        closed_set.add(node.state)

        for successor in node.expand()[::-1]:
            nodes_generated += 1
            if successor.state not in closed_set:
                fringe.put(Node(successor.state, node, node.depth + 1, heuristic(successor.state, goal)))

    return None, 0, 0, nodes_expanded, nodes_generated


   
               
def dls(start, goal, depth, heuristic):

    fringe = LifoQueue()
    closed_set = set()
    nodes_expanded = 0
    nodes_generated = 0

    fringe.put(Node(start, None, 0, heuristic(start, goal)))

    while not fringe.empty():
        node = fringe.get()
        nodes_expanded += 1

        if node.state == goal:
            path = get_path(node)
            return path, fringe.qsize(), len(closed_set), nodes_expanded, nodes_generated

        closed_set.add(node.state)

        if node.depth < depth:
            for successor in node.expand():
                nodes_generated += 1
                if successor.state not in closed_set:
                    fringe.put(Node(successor.state, node, node.depth + 1, heuristic(successor.state, goal)))

    return None, 0, len(closed_set), nodes_expanded, nodes_generated

def main():
    start_file = sys.argv[1]
    goal_file = sys.argv[2]
    method = sys.argv[3]
    dump_flag = sys.argv[4] == 'true'

    start_state = parse_input_file(start_file)
    goal_state = parse_input_file(goal_file)

    if method == 'bfs':
        solution = bfs(start_state, goal_state)
    elif method == 'dfs':
        solution = dfs(start_state, goal_state)
    elif method == 'ucs':
        solution = ucs(start_state, goal_state)
    elif method == 'greedy':
        solution = greedy(start_state, goal_state)    
    elif method == 'dls':
        solution = dls(start_state, goal_state)
    elif method == 'ids':
        solution = ids(start_state, goal_state)
    else:
        solution = astar(start_state, goal_state)

    print('Nodes Popped:', solution.nodes_popped)
    print('Nodes Expanded:', solution.nodes_expanded)
    print('Nodes Generated:', solution.nodes_generated)
    print('Max Fringe Size:', solution.max_fringe_size)

    if solution.success:
        print('Solution Found at depth', solution.depth, 'with cost of', solution.cost)
        if dump_flag:
            print('Steps:')
            for step in solution.steps:
                print('\t', step)
    else:
        print('No solution found.')
