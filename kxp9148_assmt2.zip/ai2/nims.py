import argparse
import time


class Game:
    def __init__(self, red, blue, player_turn=1):
        print(f"Starting the game with {red} red  and {blue} blue marbles")
        self.marbles = {'red': red, 'blue': blue}
        self.player_turn = player_turn

    def draw_board(self):
        print(f"Red={self.marbles['red']}, Blue={self.marbles['blue']}, Turn={self.player_turn}")

    def is_end(self):
        if self.marbles['red'] == 0:
            return self.marbles['blue'] * 3 * (1 if self.player_turn == 1 else -1)
        elif self.marbles['blue'] == 0:
            return self.marbles['red'] * 2 * (1 if self.player_turn == 1 else -1)
        else:
            return None

    def max_alpha_beta(self, alpha, beta):
        maxv = -1000
        px = None

        result = self.is_end()

        if result is not None:
            return (result, None)

        for i in ['red', 'blue']:
            self.marbles[i] -= 1
            (m, min_i) = self.min_alpha_beta(alpha, beta)
            if m > maxv:
                maxv = m
                px = i
            self.marbles[i] += 1

            if maxv >= beta:
                return (maxv, px)

            if maxv > alpha:
                alpha = maxv

        return (maxv, px)

    def min_alpha_beta(self, alpha, beta):
        minv = 1000
        qx = None

        result = self.is_end()

        if result is not None:
            return (result, None)

        for i in ['red', 'blue']:
            self.marbles[i] -= 1
            (m, max_i) = self.max_alpha_beta(alpha, beta)
            if m < minv:
                minv = m
                qx = i
            self.marbles[i] += 1

            if minv <= alpha:
                return (minv, qx)

            if minv < beta:
                beta = minv

        return (minv, qx)

    def play_alpha_beta(self):
        while True:
            self.draw_board()
            self.result = self.is_end()

            if self.result != None:
                print(f'The winner is {"Player" if self.player_turn == 1 else "Computer"} with {abs(self.result)} points!')
                return

            if self.player_turn == 1:
                while True:
                    px = input('Insert the color: ')
                    px = px.strip().lower()
                    if px in ['red', 'blue']:
                        break
                    else:
                        print(f"Invalid input {px}. Please type only 'red' or 'blue'")
                print(f"Player picks {px}")
                self.marbles[px] -= 1
                self.player_turn = 2
            # start = time.time()
            # (m, qx) = self.min_alpha_beta(-1000, 1000)
            # end = time.time()
            # print('Evaluation time: {}s'.format(round(end - start, 7)))
            # print('Recommended move: {}'.format(qx))
            else:
                (m, px) = self.max_alpha_beta(-1000, 1000)
                print(f"Computer picks {px}")
                self.marbles[px] -= 1
                self.player_turn = 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("red", type=int)
    parser.add_argument("blue", type=int)
    parser.add_argument("first_player", type=int)
    parser.add_argument("depth", type=int)
    args = parser.parse_args()
    g = Game(args.red, args.blue, args.first_player)
    g.play_alpha_beta()


if __name__ == "__main__":
    main()
